﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 5/13/2018
* CSC 153
* Alex Lopez
* display the information of three employees
*/
namespace Employee_Class
{
    public partial class Form1 : Form
    {
    public Form1()
        {
            InitializeComponent();
        }
        private void addEmployeeButton_Click(object sender, EventArgs e)
        {
            // create three employee objects and pass arguments
            Employee[] workers = new Employee[3];
            workers[0] = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            workers[1] = new Employee("Mark Jones", 39119, "IT\t", "Programmer");
            workers[2] = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            // add headers for employee information
            listBox1.Items.Add("Name\t\tID Number\tDepartment\tPosition\n");

            // add the employee information to the listBox
            for(int i = 0; i < workers.Length; i ++)
            {
                listBox1.Items.Add(workers[i].Name +"\t" + workers[i].ID + "\t\t" +
                    workers[i].Department + "\t" + workers[i].Position);
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
