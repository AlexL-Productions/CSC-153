﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class
{
    class Employee
    {
        // variables to store employee information
        private string _name;
        private int _idNumber;
        private string _department;
        private string _position;

        // Employee constructor with full parameters
        public Employee(string name, int id, string department, string title)
        {
            this._name = name;
            this._idNumber = id;
            this._department = department;
            this._position = title;
        }
        // Employee constructor with parameters and set values
        public Employee(string name, int id)
        {
            this._name = name;
            this._idNumber = id;
            _department = "";
            _position = "";
        }
        // no parameter constructor with default values
        public Employee()
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";
        }
        // method to return name value
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        // method to return idNumber value
        public int ID
        {
            get { return _idNumber; }
            set { _idNumber = value; }
        }
        // method to return department value
        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }
        // method to return position value
        public string Position
        {
            get { return _position; }
            set { _position = value; }
        }
    }
}
