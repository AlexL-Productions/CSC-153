﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Information_Class
{
    class Information
    {
        // field to store user information
        private string _name;
        private string _address;
        private int _age;
        private string _phone;

        // constructor that accepts 4 parameters
        public Information(string name, string address, int age, string phone)
        {
            _name = name;
            _address = address;
            _age = age;
            _phone = phone;
        }

        // method to get/set name
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // method to get/set address
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        // methos to get/set age
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
        
        // method to get/set phone
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }
    }
}
