﻿namespace Personal_Information_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myGroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.friendGroupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.friendGroupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.addressLabel1 = new System.Windows.Forms.Label();
            this.ageLabel1 = new System.Windows.Forms.Label();
            this.phoneLabel1 = new System.Windows.Forms.Label();
            this.nameLabel2 = new System.Windows.Forms.Label();
            this.addressLabel2 = new System.Windows.Forms.Label();
            this.ageLabel2 = new System.Windows.Forms.Label();
            this.phoneLabel2 = new System.Windows.Forms.Label();
            this.nameLabel3 = new System.Windows.Forms.Label();
            this.addressLabel3 = new System.Windows.Forms.Label();
            this.ageLabel3 = new System.Windows.Forms.Label();
            this.phoneLabel3 = new System.Windows.Forms.Label();
            this.myGroupBox.SuspendLayout();
            this.friendGroupBox1.SuspendLayout();
            this.friendGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // myGroupBox
            // 
            this.myGroupBox.Controls.Add(this.phoneLabel1);
            this.myGroupBox.Controls.Add(this.ageLabel1);
            this.myGroupBox.Controls.Add(this.addressLabel1);
            this.myGroupBox.Controls.Add(this.nameLabel1);
            this.myGroupBox.Controls.Add(this.label4);
            this.myGroupBox.Controls.Add(this.label3);
            this.myGroupBox.Controls.Add(this.label2);
            this.myGroupBox.Controls.Add(this.label1);
            this.myGroupBox.Location = new System.Drawing.Point(69, 49);
            this.myGroupBox.Name = "myGroupBox";
            this.myGroupBox.Size = new System.Drawing.Size(200, 138);
            this.myGroupBox.TabIndex = 0;
            this.myGroupBox.TabStop = false;
            this.myGroupBox.Text = "My Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Age:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone:";
            // 
            // friendGroupBox1
            // 
            this.friendGroupBox1.Controls.Add(this.phoneLabel2);
            this.friendGroupBox1.Controls.Add(this.ageLabel2);
            this.friendGroupBox1.Controls.Add(this.addressLabel2);
            this.friendGroupBox1.Controls.Add(this.nameLabel2);
            this.friendGroupBox1.Controls.Add(this.label5);
            this.friendGroupBox1.Controls.Add(this.label6);
            this.friendGroupBox1.Controls.Add(this.label7);
            this.friendGroupBox1.Controls.Add(this.label8);
            this.friendGroupBox1.Location = new System.Drawing.Point(307, 49);
            this.friendGroupBox1.Name = "friendGroupBox1";
            this.friendGroupBox1.Size = new System.Drawing.Size(200, 138);
            this.friendGroupBox1.TabIndex = 1;
            this.friendGroupBox1.TabStop = false;
            this.friendGroupBox1.Text = "Friend 1 Information";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Phone:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Age:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Address:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Name:";
            // 
            // friendGroupBox2
            // 
            this.friendGroupBox2.Controls.Add(this.phoneLabel3);
            this.friendGroupBox2.Controls.Add(this.ageLabel3);
            this.friendGroupBox2.Controls.Add(this.addressLabel3);
            this.friendGroupBox2.Controls.Add(this.nameLabel3);
            this.friendGroupBox2.Controls.Add(this.label9);
            this.friendGroupBox2.Controls.Add(this.label10);
            this.friendGroupBox2.Controls.Add(this.label11);
            this.friendGroupBox2.Controls.Add(this.label12);
            this.friendGroupBox2.Location = new System.Drawing.Point(546, 49);
            this.friendGroupBox2.Name = "friendGroupBox2";
            this.friendGroupBox2.Size = new System.Drawing.Size(200, 138);
            this.friendGroupBox2.TabIndex = 2;
            this.friendGroupBox2.TabStop = false;
            this.friendGroupBox2.Text = "Friend 2 Information";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Phone:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Age:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Address:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Name:";
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(307, 208);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(88, 35);
            this.displayButton.TabIndex = 3;
            this.displayButton.Text = "Display Information";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(427, 208);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(80, 35);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // nameLabel1
            // 
            this.nameLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLabel1.Location = new System.Drawing.Point(60, 23);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(100, 23);
            this.nameLabel1.TabIndex = 4;
            // 
            // addressLabel1
            // 
            this.addressLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addressLabel1.Location = new System.Drawing.Point(60, 48);
            this.addressLabel1.Name = "addressLabel1";
            this.addressLabel1.Size = new System.Drawing.Size(100, 23);
            this.addressLabel1.TabIndex = 5;
            // 
            // ageLabel1
            // 
            this.ageLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ageLabel1.Location = new System.Drawing.Point(60, 77);
            this.ageLabel1.Name = "ageLabel1";
            this.ageLabel1.Size = new System.Drawing.Size(100, 23);
            this.ageLabel1.TabIndex = 6;
            // 
            // phoneLabel1
            // 
            this.phoneLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneLabel1.Location = new System.Drawing.Point(60, 103);
            this.phoneLabel1.Name = "phoneLabel1";
            this.phoneLabel1.Size = new System.Drawing.Size(100, 23);
            this.phoneLabel1.TabIndex = 7;
            // 
            // nameLabel2
            // 
            this.nameLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLabel2.Location = new System.Drawing.Point(60, 23);
            this.nameLabel2.Name = "nameLabel2";
            this.nameLabel2.Size = new System.Drawing.Size(100, 23);
            this.nameLabel2.TabIndex = 5;
            // 
            // addressLabel2
            // 
            this.addressLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addressLabel2.Location = new System.Drawing.Point(60, 48);
            this.addressLabel2.Name = "addressLabel2";
            this.addressLabel2.Size = new System.Drawing.Size(100, 23);
            this.addressLabel2.TabIndex = 6;
            // 
            // ageLabel2
            // 
            this.ageLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ageLabel2.Location = new System.Drawing.Point(60, 77);
            this.ageLabel2.Name = "ageLabel2";
            this.ageLabel2.Size = new System.Drawing.Size(100, 23);
            this.ageLabel2.TabIndex = 7;
            // 
            // phoneLabel2
            // 
            this.phoneLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneLabel2.Location = new System.Drawing.Point(60, 103);
            this.phoneLabel2.Name = "phoneLabel2";
            this.phoneLabel2.Size = new System.Drawing.Size(100, 23);
            this.phoneLabel2.TabIndex = 8;
            // 
            // nameLabel3
            // 
            this.nameLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLabel3.Location = new System.Drawing.Point(60, 23);
            this.nameLabel3.Name = "nameLabel3";
            this.nameLabel3.Size = new System.Drawing.Size(100, 23);
            this.nameLabel3.TabIndex = 5;
            // 
            // addressLabel3
            // 
            this.addressLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addressLabel3.Location = new System.Drawing.Point(60, 48);
            this.addressLabel3.Name = "addressLabel3";
            this.addressLabel3.Size = new System.Drawing.Size(100, 23);
            this.addressLabel3.TabIndex = 6;
            // 
            // ageLabel3
            // 
            this.ageLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ageLabel3.Location = new System.Drawing.Point(60, 77);
            this.ageLabel3.Name = "ageLabel3";
            this.ageLabel3.Size = new System.Drawing.Size(100, 23);
            this.ageLabel3.TabIndex = 7;
            // 
            // phoneLabel3
            // 
            this.phoneLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneLabel3.Location = new System.Drawing.Point(60, 103);
            this.phoneLabel3.Name = "phoneLabel3";
            this.phoneLabel3.Size = new System.Drawing.Size(100, 23);
            this.phoneLabel3.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 255);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.friendGroupBox2);
            this.Controls.Add(this.friendGroupBox1);
            this.Controls.Add(this.myGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.myGroupBox.ResumeLayout(false);
            this.myGroupBox.PerformLayout();
            this.friendGroupBox1.ResumeLayout(false);
            this.friendGroupBox1.PerformLayout();
            this.friendGroupBox2.ResumeLayout(false);
            this.friendGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox myGroupBox;
        private System.Windows.Forms.Label phoneLabel1;
        private System.Windows.Forms.Label ageLabel1;
        private System.Windows.Forms.Label addressLabel1;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox friendGroupBox1;
        private System.Windows.Forms.Label phoneLabel2;
        private System.Windows.Forms.Label ageLabel2;
        private System.Windows.Forms.Label addressLabel2;
        private System.Windows.Forms.Label nameLabel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox friendGroupBox2;
        private System.Windows.Forms.Label phoneLabel3;
        private System.Windows.Forms.Label ageLabel3;
        private System.Windows.Forms.Label addressLabel3;
        private System.Windows.Forms.Label nameLabel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
    }
}

