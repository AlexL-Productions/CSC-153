﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 5/15/2018
* CSC 153
* Alex Lopez
* Create three instances to display
* the information of three people
*/
namespace Personal_Information_Class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // method to display my information to the labels
        private void MyInfo(Information info)
        {
            nameLabel1.Text = info.Name;
            addressLabel1.Text = info.Address;
            ageLabel1.Text = info.Age.ToString();
            phoneLabel1.Text = info.Phone;
        }
        // method to display friend1's information to the label
        private void FirstFriendInfo(Information info)
        {
            nameLabel2.Text = info.Name;
            addressLabel2.Text = info.Address;
            ageLabel2.Text = info.Age.ToString();
            phoneLabel2.Text = info.Phone;
        }
        // method to display friend2's information to the label
        private void SecondFriendInfo(Information info)
        {
            nameLabel3.Text = info.Name;
            addressLabel3.Text = info.Address;
            ageLabel3.Text = info.Age.ToString();
            phoneLabel3.Text = info.Phone;
        }
        private void displayButton_Click(object sender, EventArgs e)
        {
            // create three instances and give arguments
            Information[] Info =
            {
                new Information("Alex", "Rena Ave", 19, "910-709-8413"),
                new Information("Zevran Avari", "Antiva", 25, "910-190-2009"),
                new Information("Dorian Pavus", "Tevinter", 28, "910-944-2014")
            };

            // call the methods to display information to the label
            MyInfo(Info[0]);
            FirstFriendInfo(Info[1]);
            SecondFriendInfo(Info[2]);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
