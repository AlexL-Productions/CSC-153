﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 5/2/2018
* CSC 153
* Alex Lopez
* This program simulates a bank account
* allowing deposits and withdrawls 
* and displays the balance
*/
namespace BankAccount
{
    public partial class Form1 : Form
    {
        // instantiate an Account object with argument of 1000
        private Account account = new Account(1000);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // display the staring balance
            balanceOutput.Text = account.Balance.ToString("C");
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            decimal amount; // hold deposit input

            // convert the amount to a decimal
            if(decimal.TryParse(depositTextBox.Text, out amount))
            {
                // deposit the amount into the account
                account.Deposit(amount);

                // display the new balance
                balanceOutput.Text = account.Balance.ToString("c");

                // clear the text box
                depositTextBox.Clear();
            }
            else
            {
                // display an error message
                MessageBox.Show("invalid amount");
            }
        }

        private void withdrawButton_Click(object sender, EventArgs e)
        {
            decimal amount; // hold deposit input

            // convert the amount to a decimal
            if (decimal.TryParse(withdrawTextBox.Text, out amount))
            {
                // deposit the amount into the account
                account.Withdraw(amount);

                // display the new balance
                balanceOutput.Text = account.Balance.ToString("c");

                // clear the text box
                depositTextBox.Clear();
            }
            else
            {
                // display an error message
                MessageBox.Show("invalid amount");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
