﻿namespace BankAccount
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.depositGroupBox = new System.Windows.Forms.GroupBox();
            this.withdrawGroupBox = new System.Windows.Forms.GroupBox();
            this.balanceLabel = new System.Windows.Forms.Label();
            this.balanceOutput = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.amountLabel = new System.Windows.Forms.Label();
            this.depositTextBox = new System.Windows.Forms.TextBox();
            this.amountLabel2 = new System.Windows.Forms.Label();
            this.withdrawTextBox = new System.Windows.Forms.TextBox();
            this.depositButton = new System.Windows.Forms.Button();
            this.withdrawButton = new System.Windows.Forms.Button();
            this.depositGroupBox.SuspendLayout();
            this.withdrawGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // depositGroupBox
            // 
            this.depositGroupBox.Controls.Add(this.depositButton);
            this.depositGroupBox.Controls.Add(this.depositTextBox);
            this.depositGroupBox.Controls.Add(this.amountLabel);
            this.depositGroupBox.Location = new System.Drawing.Point(32, 91);
            this.depositGroupBox.Name = "depositGroupBox";
            this.depositGroupBox.Size = new System.Drawing.Size(200, 127);
            this.depositGroupBox.TabIndex = 0;
            this.depositGroupBox.TabStop = false;
            this.depositGroupBox.Text = "Make a Deposit";
            // 
            // withdrawGroupBox
            // 
            this.withdrawGroupBox.Controls.Add(this.withdrawButton);
            this.withdrawGroupBox.Controls.Add(this.withdrawTextBox);
            this.withdrawGroupBox.Controls.Add(this.amountLabel2);
            this.withdrawGroupBox.Location = new System.Drawing.Point(238, 91);
            this.withdrawGroupBox.Name = "withdrawGroupBox";
            this.withdrawGroupBox.Size = new System.Drawing.Size(200, 127);
            this.withdrawGroupBox.TabIndex = 1;
            this.withdrawGroupBox.TabStop = false;
            this.withdrawGroupBox.Text = "Make a Withdrawal";
            // 
            // balanceLabel
            // 
            this.balanceLabel.AutoSize = true;
            this.balanceLabel.Location = new System.Drawing.Point(163, 36);
            this.balanceLabel.Name = "balanceLabel";
            this.balanceLabel.Size = new System.Drawing.Size(52, 13);
            this.balanceLabel.TabIndex = 2;
            this.balanceLabel.Text = "Balance: ";
            // 
            // balanceOutput
            // 
            this.balanceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.balanceOutput.Location = new System.Drawing.Point(221, 35);
            this.balanceOutput.Name = "balanceOutput";
            this.balanceOutput.Size = new System.Drawing.Size(100, 23);
            this.balanceOutput.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(199, 234);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 39);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // amountLabel
            // 
            this.amountLabel.AutoSize = true;
            this.amountLabel.Location = new System.Drawing.Point(6, 38);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(46, 13);
            this.amountLabel.TabIndex = 0;
            this.amountLabel.Text = "Amount:";
            // 
            // depositTextBox
            // 
            this.depositTextBox.Location = new System.Drawing.Point(58, 35);
            this.depositTextBox.Name = "depositTextBox";
            this.depositTextBox.Size = new System.Drawing.Size(100, 20);
            this.depositTextBox.TabIndex = 1;
            // 
            // amountLabel2
            // 
            this.amountLabel2.AutoSize = true;
            this.amountLabel2.Location = new System.Drawing.Point(6, 38);
            this.amountLabel2.Name = "amountLabel2";
            this.amountLabel2.Size = new System.Drawing.Size(46, 13);
            this.amountLabel2.TabIndex = 1;
            this.amountLabel2.Text = "Amount:";
            // 
            // withdrawTextBox
            // 
            this.withdrawTextBox.Location = new System.Drawing.Point(58, 35);
            this.withdrawTextBox.Name = "withdrawTextBox";
            this.withdrawTextBox.Size = new System.Drawing.Size(100, 20);
            this.withdrawTextBox.TabIndex = 2;
            // 
            // depositButton
            // 
            this.depositButton.Location = new System.Drawing.Point(70, 71);
            this.depositButton.Name = "depositButton";
            this.depositButton.Size = new System.Drawing.Size(75, 38);
            this.depositButton.TabIndex = 2;
            this.depositButton.Text = "Deposit";
            this.depositButton.UseVisualStyleBackColor = true;
            this.depositButton.Click += new System.EventHandler(this.depositButton_Click);
            // 
            // withdrawButton
            // 
            this.withdrawButton.Location = new System.Drawing.Point(72, 71);
            this.withdrawButton.Name = "withdrawButton";
            this.withdrawButton.Size = new System.Drawing.Size(75, 38);
            this.withdrawButton.TabIndex = 3;
            this.withdrawButton.Text = "Withdraw";
            this.withdrawButton.UseVisualStyleBackColor = true;
            this.withdrawButton.Click += new System.EventHandler(this.withdrawButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 297);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.balanceOutput);
            this.Controls.Add(this.balanceLabel);
            this.Controls.Add(this.withdrawGroupBox);
            this.Controls.Add(this.depositGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.depositGroupBox.ResumeLayout(false);
            this.depositGroupBox.PerformLayout();
            this.withdrawGroupBox.ResumeLayout(false);
            this.withdrawGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox depositGroupBox;
        private System.Windows.Forms.TextBox depositTextBox;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.GroupBox withdrawGroupBox;
        private System.Windows.Forms.TextBox withdrawTextBox;
        private System.Windows.Forms.Label amountLabel2;
        private System.Windows.Forms.Label balanceLabel;
        private System.Windows.Forms.Label balanceOutput;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button depositButton;
        private System.Windows.Forms.Button withdrawButton;
    }
}

