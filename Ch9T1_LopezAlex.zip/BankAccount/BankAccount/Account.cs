﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    class Account
    {
        // feild
        private decimal _balance;

        // constructor
        public Account(decimal startingBalance)
        {
            _balance = startingBalance;
        }
        // Balance property
        public decimal Balance
        {
            get { return _balance; }
        }
        // Deposit method
        public void Deposit(decimal amount)
        {
            _balance += amount;
        }
        // Withdraw method
        public void Withdraw(decimal amount)
        {
            _balance -= amount;
        }
    }
}
