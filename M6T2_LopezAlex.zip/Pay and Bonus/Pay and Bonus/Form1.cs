﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/**
* 4/9/2018
* CSC 153
* Alex Lopez
* this program converts user input (pay and bonus) into 
* a decimal and calculates the contribution amount
*/
namespace Pay_and_Bonus
{
    public partial class Form1 : Form
    {
        // constant field for contribution
        private const decimal CONTRIB_RATE = 0.05m;
        public Form1()
        {
            InitializeComponent();
        }
        // the inputIsValid method converts input passes
        // it as an argument. The method checks for input
        // validation as well
        private bool InputIsValid(ref decimal pay, ref decimal bonus)
        {
            // set starting value to false
            bool inputGood = false;

            // validate and convert both inputs to decimal
            if(decimal.TryParse(grossPayTextBox.Text, out pay))
            {
                if(decimal.TryParse(bonusTextBox.Text, out bonus))
                {
                    // if both inputs are valid
                    inputGood = true;
                }
                else
                {
                    // display an error message for bonus
                    MessageBox.Show("bounus amount is invalid");
                }
            }
            else
            {
                // display an error message for gross pay
                MessageBox.Show("Gross pay is invalid");
            }
            // return the result
            return inputGood;
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // input variables 
            decimal grossPay = 0m, bonus = 0m, contributions = 0m;

            if(InputIsValid(ref grossPay, ref bonus))
            {
                // calculate the contribution
                contributions = (grossPay + bonus) * CONTRIB_RATE;

                // display contribution amount
                contributionLabel.Text = contributions.ToString("C");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the program
            this.Close();
        }
    }
}
