﻿namespace Rock__Paper__Scissors_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rockPicture = new System.Windows.Forms.PictureBox();
            this.paperPicture = new System.Windows.Forms.PictureBox();
            this.scissorsPicture = new System.Windows.Forms.PictureBox();
            this.promptLabel = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.playButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.rockPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // rockPicture
            // 
            this.rockPicture.Image = ((System.Drawing.Image)(resources.GetObject("rockPicture.Image")));
            this.rockPicture.Location = new System.Drawing.Point(11, 81);
            this.rockPicture.Name = "rockPicture";
            this.rockPicture.Size = new System.Drawing.Size(64, 65);
            this.rockPicture.TabIndex = 0;
            this.rockPicture.TabStop = false;
            this.rockPicture.Click += new System.EventHandler(this.rockPicture_Click);
            // 
            // paperPicture
            // 
            this.paperPicture.Image = ((System.Drawing.Image)(resources.GetObject("paperPicture.Image")));
            this.paperPicture.Location = new System.Drawing.Point(107, 81);
            this.paperPicture.Name = "paperPicture";
            this.paperPicture.Size = new System.Drawing.Size(64, 65);
            this.paperPicture.TabIndex = 1;
            this.paperPicture.TabStop = false;
            this.paperPicture.Click += new System.EventHandler(this.paperPicture_Click);
            // 
            // scissorsPicture
            // 
            this.scissorsPicture.Image = ((System.Drawing.Image)(resources.GetObject("scissorsPicture.Image")));
            this.scissorsPicture.Location = new System.Drawing.Point(205, 81);
            this.scissorsPicture.Name = "scissorsPicture";
            this.scissorsPicture.Size = new System.Drawing.Size(64, 65);
            this.scissorsPicture.TabIndex = 2;
            this.scissorsPicture.TabStop = false;
            this.scissorsPicture.Click += new System.EventHandler(this.scissorsPicture_Click);
            // 
            // promptLabel
            // 
            this.promptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.promptLabel.Location = new System.Drawing.Point(8, 19);
            this.promptLabel.Name = "promptLabel";
            this.promptLabel.Size = new System.Drawing.Size(261, 33);
            this.promptLabel.TabIndex = 3;
            this.promptLabel.Text = "You will play against the computer. Click a picture to start!";
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(12, 171);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(247, 147);
            this.listBox.TabIndex = 4;
            // 
            // playButton
            // 
            this.playButton.Location = new System.Drawing.Point(22, 336);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(75, 35);
            this.playButton.TabIndex = 5;
            this.playButton.Text = "Play!";
            this.playButton.UseVisualStyleBackColor = true;
            this.playButton.Click += new System.EventHandler(this.playButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(184, 336);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 35);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(103, 336);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 35);
            this.resetButton.TabIndex = 7;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 394);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.promptLabel);
            this.Controls.Add(this.scissorsPicture);
            this.Controls.Add(this.paperPicture);
            this.Controls.Add(this.rockPicture);
            this.Name = "Form1";
            this.Text = "RockPaperScissors";
            ((System.ComponentModel.ISupportInitialize)(this.rockPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox rockPicture;
        private System.Windows.Forms.PictureBox paperPicture;
        private System.Windows.Forms.PictureBox scissorsPicture;
        private System.Windows.Forms.Label promptLabel;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button playButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button resetButton;
    }
}

