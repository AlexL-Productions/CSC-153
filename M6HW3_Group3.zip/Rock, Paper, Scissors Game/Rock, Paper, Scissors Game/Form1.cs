﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 4/24/2018
* CSC 153
* Group 3
* Alex Lopez - Program code. Rashad Henry - Pseudocode. Aaron Williams - Flowchart.
* This game plays you against the computer
* you will choose rock, paper, or scissors
* and the winner will be determined
*/
namespace Rock__Paper__Scissors_Game
{
    public partial class Form1 : Form
    {
        // create variables to hold the number
        // of the player and computer (choice value)
        int playerNum;
        int comNum;
        public Form1()
        {
            InitializeComponent();
        }
        // this is the Click_Event for the picture rock
        // a random number is generated for the computer
        // the users number is assigned to 1. 
        private void rockPicture_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            comNum = rand.Next(1, 3);
            playerNum = 1;

            listBox.Items.Add("You chose rock!");  
        }
        // this is the Click_Event for the picture paper
        // a random number is generated for the computer
        // the users number is assigned to 2
        private void paperPicture_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            comNum = rand.Next(1, 3);
            playerNum = 2; 

            listBox.Items.Add("You chose paper!");   
        }
        // this is the Click_Event for the picture scissors
        // a random number is generated for the computer
        // the users number is assigned to 3
        private void scissorsPicture_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            comNum = rand.Next(1, 3);
            playerNum = 3;

            listBox.Items.Add("You chose scissors!");
        }
        // this method determines the winner by comparing 
        // the user's and computer's number to each other
        // the outcome is displayed in the listBox
        private void SelectWinner(int player, int computer)
        {
            if (player == computer)
            {
                listBox.Items.Add("Draw!!!\n");
            }
            if(player == 2 && computer == 1)
            {
                listBox.Items.Add("You Win!!!\n");          
            }
            if (player == 1 && computer == 2)
            {
                listBox.Items.Add("You Lose!!!\n");
            }
            if (player == 1 && computer == 3)
            {
                listBox.Items.Add("You Win!!!\n");
            }
            else if (player == 3 && computer == 1)
            {
                listBox.Items.Add("You Lose!!!\n");
            }
            if (player == 3 && computer == 2)
            {
                listBox.Items.Add("You Win!!!\n");
            }
            else if (player ==2 && computer == 3)
            {
                listBox.Items.Add("You Lose!!!\n");
            }     
        }
        private void playButton_Click(object sender, EventArgs e)
        {
            // after the user clicks a picture
            // the computer's number is evaluated and 
            // the corresponding text is displayed in listBox
            switch (comNum)
            {
                case 1:
                    listBox.Items.Add("Computer chooses rock!");
                    break;
                case 2:
                    listBox.Items.Add("Computer chooses paper!");
                    break;
                case 3:
                    listBox.Items.Add("Computer chooses scissors!");
                    break;
            }

            // we call this method and pass the
            // player's and computer's score number
            // as arguments to determine the winner
            SelectWinner(playerNum, comNum);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // clear the listBox
            listBox.Items.Clear();
        }
    }
}
