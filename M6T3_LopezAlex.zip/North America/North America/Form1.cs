﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

/**
* 4/16/2018
* CSC 153
* Alex Lopez
* This program lets you open a file and 
* displays it's content in a list box
*/
namespace North_America
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // the GetFileName method opens a file and passes it as an argument
        private void GetFileName(out string selectedFile)
        {
            if(openFile.ShowDialog() == DialogResult.OK)
            {
                selectedFile = openFile.FileName;
            }
            else
            {
                selectedFile = "";
            }
        }
        // GetCountries method accepts a filename as an argument
        // It reads the file and displays its content
        private void GetCountries(string fileName)
        {
            try
            {
                // create variable to hold country name
                string countryName;

                // create streamReader variable
                StreamReader inputFile = File.OpenText(fileName);

                // clear the lsitBox
                countriesListBox.Items.Clear();

                // read the file's contents
                while (!inputFile.EndOfStream)
                {
                    // get a contry name
                    countryName = inputFile.ReadLine();

                    // add the country name to the listBox
                    countriesListBox.Items.Add(countryName);

                    // clos ethe fiel
                    inputFile.Close();
                }
            }
            catch (Exception ex)
            {
                // display an error message
                MessageBox.Show(ex.Message);
            }
        }
        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            string filename;

            // get the fileName from the user
            GetFileName(out filename);

            // get the countries from the file
            GetCountries(filename);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
