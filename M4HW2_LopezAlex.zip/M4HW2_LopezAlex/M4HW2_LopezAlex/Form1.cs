﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * 3/30/2018
 * CSC 153
 * Alex Lopez
 * Dice Roll simulator
 * */

namespace M4HW2_LopezAlex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            //create variables to hold our dice numbers
            int diceNum1, diceNum2;
            
            //get a random object for numbers 1-6
            Random rand = new Random();

            //assign random number to variables
            diceNum1 = rand.Next(6) + 1;
            diceNum2 = rand.Next(6) + 1;
            
            //set all pictureBox to non-visible
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            pictureBox6.Visible = false;

            //show dice image for corresponding dice number
            if (diceNum1 == 1)
            {
                pictureBox1.Visible = true;
            }
            else if (diceNum1 == 2)
            {
                pictureBox2.Visible = true;
            }
            else if (diceNum1 == 3)
            {
                pictureBox3.Visible = true;
            }
            else if (diceNum1 == 4)
            {
                pictureBox4.Visible = true;
            }
            else if (diceNum1 == 5)
            {
                pictureBox5.Visible = true;
            }
            else if (diceNum1 == 6)
            {
                pictureBox6.Visible = true;
            }

            //display the dice number
            outputLabel1.Text = diceNum1.ToString();

            //show dice image for corresponding dice number
            if (diceNum2 == 1)
            {
                pictureBox1.Visible = true;
            }
            else if (diceNum2 == 2)
            {
                pictureBox2.Visible = true;
            }
            else if (diceNum2 == 3)
            {
                pictureBox3.Visible = true;
            }
            else if (diceNum2 == 4)
            {
                pictureBox4.Visible = true;
            }
            else if (diceNum2 == 5)
            {
                pictureBox5.Visible = true;
            }
            else if (diceNum2 == 6)
            {
                pictureBox6.Visible = true;
            }

            //display dice number
            outputLabel2.Text = diceNum2.ToString();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the program
            this.Close();
        }
    }
}
        