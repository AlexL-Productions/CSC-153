﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 5/16/2018
* CSC 153
* Alex Lopez
* Enter the miles driven and 
* gallons used to get the MPG
*/
namespace Fuel_Economy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;
            double gallons;
            double mpg;

            // validate miles input
            if(double.TryParse(milesTextBox.Text, out miles))
            {
                if(double.TryParse(gallonsTextBox.Text, out gallons))
                {
                    // calculate MPG
                    mpg = miles / gallons;
                    // display teh MPG to the label
                    mpgLabel.Text = mpg.ToString("n1");
                }
                else
                {
                    // display error message
                    MessageBox.Show("Invalid input for gallons");
                }
            }
            else
            {
                // display error message
                MessageBox.Show("Invalid input for miles");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
