﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 3/21/2018
* CSC 153
* Alex Lopez
* Read the End of a File
*/

namespace South_America
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            try
            {
                //declare a variable to hold the names of the countries
                string countryName;

                //create a StreamReader variable to reference our file
                StreamReader inputFile;
                
                //open the file
                inputFile = File.OpenText("Countries.txt");

                //clear list box before reading
                countriesListBox.Items.Clear();

                //read file's content
                while(!inputFile.EndOfStream)
                {
                    //read country name
                    countryName = inputFile.ReadLine();

                    //add the countries to the list box
                    countriesListBox.Items.Add(countryName);
                }

                //close the file
                inputFile.Close();
            }
            catch(Exception ex)
            {
                //display exception error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
