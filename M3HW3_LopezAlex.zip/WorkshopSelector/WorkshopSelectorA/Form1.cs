﻿/*
 * 3/2/2018
 * CSC 153
 * Byron Jackson
 * Alex Lopez
 * Hilary Agbele
 * This program use list boxs and switch statements to calculate workshop cost 
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopSelectorA
{
    public partial class WorkshopSelector : Form
    {
        public WorkshopSelector()
        {
            InitializeComponent();
        }

        string workShop;
        string location;
        decimal totalCost;
        decimal W;
        decimal L;
        int days;

        private void button1_Click(object sender, EventArgs e)
        {
            

            if (listBox1.SelectedIndex != -1)
            {
                //Get the Selected item
                workShop = listBox1.SelectedItem.ToString();

                //Determine Workshop
                switch (workShop)
                {
                    case "Handling Stress":
                        label1.Text = "Handle Stress is 3 days and a $1000 registration fee";
                        W = 1000m;  days = 3; 
                        break;
                    case "Time Management":
                        label1.Text = "Time Management is a 3 days long with $800 registration fee";
                        W = 800m; days = 3;
                        break;
                    case "Supervision Skills":
                        label1.Text = "Supervision Skills is 3 days long with $1500 registration fee.";
                        W = 1500m; days = 3;
                        break;
                    case "Negotiation":
                        label1.Text = "Negotiation is 5 days long with a $1300 registration fee.";
                        W = 1300m; days = 5;
                        break;
                    case "How to Interview":
                        label1.Text = "How to Interview is 1 day long with a $500 registration fee.";
                        W = 500m; days = 1;
                        break;
                }
            }
            else
            {
                //Give help message
                MessageBox.Show("Choose a Workshop");
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(listBox2.SelectedIndex != -1)
            {
                //get the selected item.
                location = listBox2.SelectedItem.ToString();

                //Determine location.
                switch (location)
                {
                    case "Austin":
                        label2.Text = "Austin cost $150 per day";
                        L = 150m;
                        break;
                    case "Chicago":
                        label2.Text = "Chicago cost 225 per day";
                        L = 225m;
                        break;
                    case "Dallas":
                        label2.Text = "Dallas cost 175 per day";
                        L = 175m;
                        break;

                    case "Orlando":
                        label2.Text = "Orlando cost $300 per day";
                        L = 300m;
                        break;
                    case "Phoenix":
                        label2.Text = "Phoenix cost $175 per day";
                        L = 175m;
                        break;
                    case "Raleigh":
                        label2.Text = "Raleigh cost $150 per day";
                        L = 150m;
                        break;
                }

            }
            else
            {
                //Display help message
                MessageBox.Show("Choose a location");
            }
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            //Calculate Workshop total cost
            totalCost = ((days * L) + W);
            totalLabel.Text = totalCost.ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
