﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 5/16/2018
* CSC 153
* Alex Lopez
* enter financial data to
* calculate your gross pay
*/
namespace Payroll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // name constants
                const decimal BaseHours = 40m;
                const decimal OtMultiplier = 1.5m;

                // local variables
                decimal hoursWorked;
                decimal hourlyPayRate;
                decimal basePay;
                decimal overtimeHours;
                decimal overtimePay;
                decimal grossPay;

                // get the hours worked and hourly pay rate
                hoursWorked = decimal.Parse(hoursTextBox.Text);
                hourlyPayRate = decimal.Parse(payTextBox.Text);

                // validate gross pay
                if(hoursWorked > BaseHours)
                {
                    basePay = hourlyPayRate * BaseHours;

                    overtimeHours = hoursWorked - BaseHours;

                    overtimePay = overtimeHours * hourlyPayRate * OtMultiplier;

                    grossPay = basePay + overtimePay;
                }
                else
                {
                    grossPay = hoursWorked * hourlyPayRate;
                }

                grossLabel.Text = grossPay.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            hoursTextBox.Text = "";
            payTextBox.Text = "";
            grossLabel.Text = "";

            hoursTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
