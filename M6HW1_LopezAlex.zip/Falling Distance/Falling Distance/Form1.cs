﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 4/16/2018
* CSC 153
* Alex Lopez
* This program calculates the distance of a falling object.
*/

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // FallingDistance method to calculate the distance
        // user input is passed as the parameter
        private double FallingDistance(double fallingTime)
        {   
            // calculate the distance and return the new value
            return fallingTime = .5 * 9.8 * (Math.Pow(fallingTime, fallingTime));
        }
        private void calculateDistanceButton_Click(object sender, EventArgs e)
        {
            // double variables to hold input and output
            double fallingTime, distance;

            // validate input get the speed of a falling object
            if (double.TryParse(timeTextBox.Text, out fallingTime))
            {
                // get the falling distance and 
                // assign the value to distance
                distance = FallingDistance(fallingTime);

                // display, and format the distance 
                distanceOutputLabel.Text = distance.ToString("n1");
            }
            // display an error message
            else
            {
                MessageBox.Show("input must be a number.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
