﻿namespace Falling_Distance
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.timePrompt = new System.Windows.Forms.Label();
            this.timeTextBox = new System.Windows.Forms.TextBox();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.distanceOutputLabel = new System.Windows.Forms.Label();
            this.calculateDistanceButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timePrompt
            // 
            this.timePrompt.Location = new System.Drawing.Point(26, 45);
            this.timePrompt.Name = "timePrompt";
            this.timePrompt.Size = new System.Drawing.Size(112, 23);
            this.timePrompt.TabIndex = 0;
            this.timePrompt.Text = "Time of falling object:";
            this.timePrompt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timeTextBox
            // 
            this.timeTextBox.Location = new System.Drawing.Point(144, 47);
            this.timeTextBox.Name = "timeTextBox";
            this.timeTextBox.Size = new System.Drawing.Size(100, 20);
            this.timeTextBox.TabIndex = 1;
            // 
            // distanceLabel
            // 
            this.distanceLabel.Location = new System.Drawing.Point(12, 91);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(126, 23);
            this.distanceLabel.TabIndex = 2;
            this.distanceLabel.Text = "Distanc of falling object:";
            this.distanceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // distanceOutputLabel
            // 
            this.distanceOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.distanceOutputLabel.Location = new System.Drawing.Point(144, 91);
            this.distanceOutputLabel.Name = "distanceOutputLabel";
            this.distanceOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.distanceOutputLabel.TabIndex = 3;
            // 
            // calculateDistanceButton
            // 
            this.calculateDistanceButton.Location = new System.Drawing.Point(51, 162);
            this.calculateDistanceButton.Name = "calculateDistanceButton";
            this.calculateDistanceButton.Size = new System.Drawing.Size(75, 34);
            this.calculateDistanceButton.TabIndex = 4;
            this.calculateDistanceButton.Text = "Calculate Distance";
            this.calculateDistanceButton.UseVisualStyleBackColor = true;
            this.calculateDistanceButton.Click += new System.EventHandler(this.calculateDistanceButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(144, 162);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 34);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateDistanceButton);
            this.Controls.Add(this.distanceOutputLabel);
            this.Controls.Add(this.distanceLabel);
            this.Controls.Add(this.timeTextBox);
            this.Controls.Add(this.timePrompt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label timePrompt;
        private System.Windows.Forms.TextBox timeTextBox;
        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.Label distanceOutputLabel;
        private System.Windows.Forms.Button calculateDistanceButton;
        private System.Windows.Forms.Button exitButton;
    }
}

