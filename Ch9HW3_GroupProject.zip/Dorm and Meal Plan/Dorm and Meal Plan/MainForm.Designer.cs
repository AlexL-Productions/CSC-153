﻿namespace Dorm_and_Meal_Plan
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormGroupBox = new System.Windows.Forms.GroupBox();
            this.dormPlan4 = new System.Windows.Forms.RadioButton();
            this.dormPlan3 = new System.Windows.Forms.RadioButton();
            this.dormPlan2 = new System.Windows.Forms.RadioButton();
            this.dormPlan1 = new System.Windows.Forms.RadioButton();
            this.mealGroupBox = new System.Windows.Forms.GroupBox();
            this.mealPlan3 = new System.Windows.Forms.RadioButton();
            this.mealPlan2 = new System.Windows.Forms.RadioButton();
            this.mealPlan1 = new System.Windows.Forms.RadioButton();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.dormGroupBox.SuspendLayout();
            this.mealGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dormGroupBox
            // 
            this.dormGroupBox.Controls.Add(this.dormPlan4);
            this.dormGroupBox.Controls.Add(this.dormPlan3);
            this.dormGroupBox.Controls.Add(this.dormPlan2);
            this.dormGroupBox.Controls.Add(this.dormPlan1);
            this.dormGroupBox.Location = new System.Drawing.Point(41, 46);
            this.dormGroupBox.Name = "dormGroupBox";
            this.dormGroupBox.Size = new System.Drawing.Size(231, 136);
            this.dormGroupBox.TabIndex = 0;
            this.dormGroupBox.TabStop = false;
            this.dormGroupBox.Text = "Select a Dorm Plan";
            // 
            // dormPlan4
            // 
            this.dormPlan4.AutoSize = true;
            this.dormPlan4.Location = new System.Drawing.Point(6, 99);
            this.dormPlan4.Name = "dormPlan4";
            this.dormPlan4.Size = new System.Drawing.Size(208, 17);
            this.dormPlan4.TabIndex = 3;
            this.dormPlan4.TabStop = true;
            this.dormPlan4.Text = "University Suites - $2,500 per semester";
            this.dormPlan4.UseVisualStyleBackColor = true;
            // 
            // dormPlan3
            // 
            this.dormPlan3.AutoSize = true;
            this.dormPlan3.Location = new System.Drawing.Point(6, 76);
            this.dormPlan3.Name = "dormPlan3";
            this.dormPlan3.Size = new System.Drawing.Size(189, 17);
            this.dormPlan3.TabIndex = 2;
            this.dormPlan3.TabStop = true;
            this.dormPlan3.Text = "Farthing Hall - $1,800 per semester";
            this.dormPlan3.UseVisualStyleBackColor = true;
            // 
            // dormPlan2
            // 
            this.dormPlan2.AutoSize = true;
            this.dormPlan2.Location = new System.Drawing.Point(6, 53);
            this.dormPlan2.Name = "dormPlan2";
            this.dormPlan2.Size = new System.Drawing.Size(172, 17);
            this.dormPlan2.TabIndex = 1;
            this.dormPlan2.TabStop = true;
            this.dormPlan2.Text = "Pike Hall - $1.600 per semseter";
            this.dormPlan2.UseVisualStyleBackColor = true;
            // 
            // dormPlan1
            // 
            this.dormPlan1.AutoSize = true;
            this.dormPlan1.Location = new System.Drawing.Point(6, 30);
            this.dormPlan1.Name = "dormPlan1";
            this.dormPlan1.Size = new System.Drawing.Size(174, 17);
            this.dormPlan1.TabIndex = 0;
            this.dormPlan1.TabStop = true;
            this.dormPlan1.Text = "Allen Hall - $1,500 per semester";
            this.dormPlan1.UseVisualStyleBackColor = true;
            // 
            // mealGroupBox
            // 
            this.mealGroupBox.Controls.Add(this.mealPlan3);
            this.mealGroupBox.Controls.Add(this.mealPlan2);
            this.mealGroupBox.Controls.Add(this.mealPlan1);
            this.mealGroupBox.Location = new System.Drawing.Point(349, 46);
            this.mealGroupBox.Name = "mealGroupBox";
            this.mealGroupBox.Size = new System.Drawing.Size(231, 136);
            this.mealGroupBox.TabIndex = 1;
            this.mealGroupBox.TabStop = false;
            this.mealGroupBox.Text = "Select a Meal Plan";
            // 
            // mealPlan3
            // 
            this.mealPlan3.AutoSize = true;
            this.mealPlan3.Location = new System.Drawing.Point(6, 74);
            this.mealPlan3.Name = "mealPlan3";
            this.mealPlan3.Size = new System.Drawing.Size(187, 17);
            this.mealPlan3.TabIndex = 2;
            this.mealPlan3.TabStop = true;
            this.mealPlan3.Text = "Unlimited meals - $1,700/semester";
            this.mealPlan3.UseVisualStyleBackColor = true;
            // 
            // mealPlan2
            // 
            this.mealPlan2.AutoSize = true;
            this.mealPlan2.Location = new System.Drawing.Point(6, 51);
            this.mealPlan2.Name = "mealPlan2";
            this.mealPlan2.Size = new System.Drawing.Size(187, 17);
            this.mealPlan2.TabIndex = 1;
            this.mealPlan2.TabStop = true;
            this.mealPlan2.Text = "14 meals/week - $1,200/semester";
            this.mealPlan2.UseVisualStyleBackColor = true;
            // 
            // mealPlan1
            // 
            this.mealPlan1.AutoSize = true;
            this.mealPlan1.Location = new System.Drawing.Point(6, 28);
            this.mealPlan1.Name = "mealPlan1";
            this.mealPlan1.Size = new System.Drawing.Size(172, 17);
            this.mealPlan1.TabIndex = 0;
            this.mealPlan1.TabStop = true;
            this.mealPlan1.Text = "7 meals/week - $600/semester";
            this.mealPlan1.UseVisualStyleBackColor = true;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(177, 236);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(95, 43);
            this.submitButton.TabIndex = 2;
            this.submitButton.Text = "Submit Plan";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(349, 236);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 43);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 305);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.mealGroupBox);
            this.Controls.Add(this.dormGroupBox);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.dormGroupBox.ResumeLayout(false);
            this.dormGroupBox.PerformLayout();
            this.mealGroupBox.ResumeLayout(false);
            this.mealGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox dormGroupBox;
        private System.Windows.Forms.RadioButton dormPlan4;
        private System.Windows.Forms.RadioButton dormPlan3;
        private System.Windows.Forms.RadioButton dormPlan2;
        private System.Windows.Forms.RadioButton dormPlan1;
        private System.Windows.Forms.GroupBox mealGroupBox;
        private System.Windows.Forms.RadioButton mealPlan3;
        private System.Windows.Forms.RadioButton mealPlan2;
        private System.Windows.Forms.RadioButton mealPlan1;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
    }
}

