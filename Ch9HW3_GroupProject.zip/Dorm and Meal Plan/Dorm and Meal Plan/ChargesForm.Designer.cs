﻿namespace Dorm_and_Meal_Plan
{
    partial class ChargesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buildingLabel = new System.Windows.Forms.Label();
            this.dormBuildingLabel = new System.Windows.Forms.Label();
            this.chargesLabel = new System.Windows.Forms.Label();
            this.mealFeeLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.feeLabel = new System.Windows.Forms.Label();
            this.totalChargesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buildingLabel
            // 
            this.buildingLabel.AutoSize = true;
            this.buildingLabel.Location = new System.Drawing.Point(68, 55);
            this.buildingLabel.Name = "buildingLabel";
            this.buildingLabel.Size = new System.Drawing.Size(59, 13);
            this.buildingLabel.TabIndex = 0;
            this.buildingLabel.Text = "Dorm Plan:";
            // 
            // dormBuildingLabel
            // 
            this.dormBuildingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dormBuildingLabel.Location = new System.Drawing.Point(134, 54);
            this.dormBuildingLabel.Name = "dormBuildingLabel";
            this.dormBuildingLabel.Size = new System.Drawing.Size(263, 23);
            this.dormBuildingLabel.TabIndex = 2;
            // 
            // chargesLabel
            // 
            this.chargesLabel.AutoSize = true;
            this.chargesLabel.Location = new System.Drawing.Point(51, 155);
            this.chargesLabel.Name = "chargesLabel";
            this.chargesLabel.Size = new System.Drawing.Size(76, 13);
            this.chargesLabel.TabIndex = 4;
            this.chargesLabel.Text = "Total Charges:";
            // 
            // mealFeeLabel
            // 
            this.mealFeeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mealFeeLabel.Location = new System.Drawing.Point(134, 102);
            this.mealFeeLabel.Name = "mealFeeLabel";
            this.mealFeeLabel.Size = new System.Drawing.Size(263, 23);
            this.mealFeeLabel.TabIndex = 5;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(134, 226);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 6;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // feeLabel
            // 
            this.feeLabel.AutoSize = true;
            this.feeLabel.Location = new System.Drawing.Point(68, 103);
            this.feeLabel.Name = "feeLabel";
            this.feeLabel.Size = new System.Drawing.Size(57, 13);
            this.feeLabel.TabIndex = 9;
            this.feeLabel.Text = "Meal Plan:";
            // 
            // totalChargesLabel
            // 
            this.totalChargesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalChargesLabel.Location = new System.Drawing.Point(134, 154);
            this.totalChargesLabel.Name = "totalChargesLabel";
            this.totalChargesLabel.Size = new System.Drawing.Size(263, 23);
            this.totalChargesLabel.TabIndex = 10;
            // 
            // ChargesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 287);
            this.Controls.Add(this.totalChargesLabel);
            this.Controls.Add(this.feeLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.mealFeeLabel);
            this.Controls.Add(this.chargesLabel);
            this.Controls.Add(this.dormBuildingLabel);
            this.Controls.Add(this.buildingLabel);
            this.Name = "ChargesForm";
            this.Text = "ChargesForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label buildingLabel;
        private System.Windows.Forms.Label chargesLabel;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label feeLabel;
        public System.Windows.Forms.Label totalChargesLabel;
        public System.Windows.Forms.Label dormBuildingLabel;
        public System.Windows.Forms.Label mealFeeLabel;
    }
}