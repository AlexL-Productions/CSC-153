﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 5/15/2018
* CSC 153
* Alex Lopez
* Make a dorm and meal plan selection
* and your invoice will be displayed
*/
namespace Dorm_and_Meal_Plan
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            // new ChargesForm object
            ChargesForm charges = new ChargesForm(); 

            // variables to hold dorm and meal prices
            int dormPrice = 0;
            int mealPrice = 0;

            // boolean variable to test dorm radiobutton
            bool dormPlanSelected;
            // boolean variable to test meal radiobutton
            bool mealPlanSelected;

            // if user checks plan 1
            if (dormPlanSelected = dormPlan1.Checked)
            {
                charges.dormBuildingLabel.Text = dormPlan1.Text;    // display the text of the buttont to the label
                dormPrice = 1500;                                   // set dorm price
            }
            // if user checks plan 2
            if (dormPlanSelected = dormPlan2.Checked)
            {
                charges.dormBuildingLabel.Text = dormPlan2.Text;    // display the text of the buttont to the label
                dormPrice = 1600;                                   // set the dorm price
            }   
            // if user checks plan 3
            if (dormPlanSelected = dormPlan3.Checked)
            {
                charges.dormBuildingLabel.Text = dormPlan3.Text;    // display the text of the buttont to the label
                dormPrice = 1800;                                   // set the dorm price
            }
            // if user checks plan 4
            if (dormPlanSelected = dormPlan4.Checked)
            {
                charges.dormBuildingLabel.Text = dormPlan4.Text;    // display the text of the buttont to the label
                dormPrice = 2500;                                   // set the dorm price
            }

            // if user checks plan 1
            if (mealPlanSelected = mealPlan1.Checked)
            {
                charges.mealFeeLabel.Text = mealPlan1.Text;     // display the text of the buttont to the label
                mealPrice = 600;                                // set the meal price
            }
            // if user checks plan 2
            if (mealPlanSelected = mealPlan2.Checked)
            {
                charges.mealFeeLabel.Text = mealPlan2.Text;     // display the text of the buttont to the label
                mealPrice = 1200;                               // set the meal price
            }
            // if user checks plan 3
            if (mealPlanSelected = mealPlan3.Checked)
            {
                charges.mealFeeLabel.Text = mealPlan3.Text;     // display the text of the buttont to the label
                mealPrice = 1700;                               // set the meal price
            }

            // display the total of dorm and meal price to the label
            charges.totalChargesLabel.Text = (dormPrice + mealPrice).ToString("c");
            // display the form
            charges.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
