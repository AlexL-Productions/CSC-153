﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class
{
    public partial class Form1 : Form
    {
        // create a pet list to store pet objects
        List<Pet> petList = new List<Pet>();

        public Form1()
        {
            InitializeComponent();
        }
        // the GetPetData method accepts a Pet object
        // and stores user input in it's variables
        private void GetPetData(Pet pet)
        {
            // int variable to store age
            int age;

            // get text from the user and assign to varaible
            pet.name = nameTextBox.Text;
            pet.type = typeTextBox.Text;
            
            // input validation for age
            if(int.TryParse(ageTextBox.Text, out age))
            {
                pet.age = age;
            }
            // exception message
            else
            {
                MessageBox.Show("Invalid age data");
                pet.name = "";
                pet.type = "";
                pet.age = 0;
                nameTextBox.Clear();
                typeTextBox.Clear();
                nameTextBox.Focus();
            }

        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            // create a Pet object
            Pet myPet = new Pet();

            // call method to get pet data
            GetPetData(myPet);

            // add the object to the list
            petList.Add(myPet);

            // get data from the Pet object and add it to the petListBox
            petListBox.Items.Add(myPet.Name);
            petListBox.Items.Add(myPet.Type);
            petListBox.Items.Add(myPet.Age);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
