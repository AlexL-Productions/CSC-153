﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Class
{
    class Pet
    {
        // variables to hold pet information
        public string name;
        public string type;
        public int age;

        // constructor sets the default values
        public Pet()
        {
            name = "";
            type = "";
            age = 0;
        }

        // return the value of name variable
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        // return the value of type variable
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        // return the value of age variable
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
    }
}
