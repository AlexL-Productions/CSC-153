﻿namespace Pet_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namePrompt = new System.Windows.Forms.Label();
            this.typePrompt = new System.Windows.Forms.Label();
            this.agePrompt = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.typeTextBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.petListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // namePrompt
            // 
            this.namePrompt.Location = new System.Drawing.Point(46, 62);
            this.namePrompt.Name = "namePrompt";
            this.namePrompt.Size = new System.Drawing.Size(100, 23);
            this.namePrompt.TabIndex = 0;
            this.namePrompt.Text = "Name:";
            // 
            // typePrompt
            // 
            this.typePrompt.Location = new System.Drawing.Point(46, 100);
            this.typePrompt.Name = "typePrompt";
            this.typePrompt.Size = new System.Drawing.Size(100, 23);
            this.typePrompt.TabIndex = 1;
            this.typePrompt.Text = "Type:";
            // 
            // agePrompt
            // 
            this.agePrompt.Location = new System.Drawing.Point(46, 136);
            this.agePrompt.Name = "agePrompt";
            this.agePrompt.Size = new System.Drawing.Size(100, 23);
            this.agePrompt.TabIndex = 2;
            this.agePrompt.Text = "Age:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(118, 62);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 3;
            // 
            // typeTextBox
            // 
            this.typeTextBox.Location = new System.Drawing.Point(118, 100);
            this.typeTextBox.Name = "typeTextBox";
            this.typeTextBox.Size = new System.Drawing.Size(100, 20);
            this.typeTextBox.TabIndex = 4;
            // 
            // ageTextBox
            // 
            this.ageTextBox.Location = new System.Drawing.Point(118, 136);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(100, 20);
            this.ageTextBox.TabIndex = 5;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(49, 205);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 23);
            this.submitButton.TabIndex = 6;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(143, 205);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // petListBox
            // 
            this.petListBox.FormattingEnabled = true;
            this.petListBox.Location = new System.Drawing.Point(276, 62);
            this.petListBox.Name = "petListBox";
            this.petListBox.Size = new System.Drawing.Size(120, 95);
            this.petListBox.TabIndex = 8;
            
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 261);
            this.Controls.Add(this.petListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.typeTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.agePrompt);
            this.Controls.Add(this.typePrompt);
            this.Controls.Add(this.namePrompt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label namePrompt;
        private System.Windows.Forms.Label typePrompt;
        private System.Windows.Forms.Label agePrompt;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox typeTextBox;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox petListBox;
    }
}

