﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Class
{
    class Vehicle
    {
        // variables to hold information
        private int _year;
        private string _make;
        private int _speed;
        
        // constructor with two parameters and default value
        public Vehicle(int year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }
        // method to increase the vehicles speed
        public void Accelerate()
        {
            _speed += 5;
        }
        // method to decrease the vehicles speed
        public void Brake()
        {
            _speed -= 5;
        }
        // method to return the value of _year
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }
        // method to return the value of _make
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }
        // method to return the value of _speed
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
    }
}
