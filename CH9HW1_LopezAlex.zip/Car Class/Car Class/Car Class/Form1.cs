﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Class
{
    public partial class Form1 : Form
    {
        Vehicle myCar = new Vehicle(2018, "Ford F-150");
        
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            yearOutput.Text = myCar.Year.ToString();
            makeOutput.Text = myCar.Make;
        }
        private void accelerateButton_MouseDown(object sender, MouseEventArgs e)
        {
            myCar.Accelerate();
            speedOutput.Text = myCar.Speed.ToString();
        }
        private void accelerateButton_Click(object sender, EventArgs e)
        {
            myCar.Accelerate();
            speedOutput.Text = myCar.Speed.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            myCar.Brake();
            speedOutput.Text = myCar.Speed.ToString();
        }
    }
}
