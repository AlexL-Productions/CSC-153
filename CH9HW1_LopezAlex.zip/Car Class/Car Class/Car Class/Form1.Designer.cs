﻿namespace Car_Class
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.speedLabel = new System.Windows.Forms.Label();
            this.speedOutput = new System.Windows.Forms.Label();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.brakeButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.makeLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.yearOutput = new System.Windows.Forms.Label();
            this.makeOutput = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(6, 143);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(78, 13);
            this.speedLabel.TabIndex = 0;
            this.speedLabel.Text = "Current Speed:";
            // 
            // speedOutput
            // 
            this.speedOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.speedOutput.Location = new System.Drawing.Point(124, 142);
            this.speedOutput.Name = "speedOutput";
            this.speedOutput.Size = new System.Drawing.Size(100, 23);
            this.speedOutput.TabIndex = 1;
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(256, 221);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.Size = new System.Drawing.Size(87, 36);
            this.accelerateButton.TabIndex = 3;
            this.accelerateButton.Text = "Accelerate";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // brakeButton
            // 
            this.brakeButton.Location = new System.Drawing.Point(113, 221);
            this.brakeButton.Name = "brakeButton";
            this.brakeButton.Size = new System.Drawing.Size(84, 36);
            this.brakeButton.TabIndex = 4;
            this.brakeButton.Text = "Brake";
            this.brakeButton.UseVisualStyleBackColor = true;
            this.brakeButton.Click += new System.EventHandler(this.brakeButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.makeOutput);
            this.groupBox1.Controls.Add(this.yearOutput);
            this.groupBox1.Controls.Add(this.yearLabel);
            this.groupBox1.Controls.Add(this.makeLabel);
            this.groupBox1.Controls.Add(this.speedLabel);
            this.groupBox1.Controls.Add(this.speedOutput);
            this.groupBox1.Location = new System.Drawing.Point(113, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(230, 181);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter Vehicle Data";
            // 
            // makeLabel
            // 
            this.makeLabel.AutoSize = true;
            this.makeLabel.Location = new System.Drawing.Point(6, 65);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(37, 13);
            this.makeLabel.TabIndex = 0;
            this.makeLabel.Text = "Make:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(6, 29);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(32, 13);
            this.yearLabel.TabIndex = 1;
            this.yearLabel.Text = "Year:";
            // 
            // yearOutput
            // 
            this.yearOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.yearOutput.Location = new System.Drawing.Point(124, 28);
            this.yearOutput.Name = "yearOutput";
            this.yearOutput.Size = new System.Drawing.Size(100, 23);
            this.yearOutput.TabIndex = 2;
            // 
            // makeOutput
            // 
            this.makeOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.makeOutput.Location = new System.Drawing.Point(124, 64);
            this.makeOutput.Name = "makeOutput";
            this.makeOutput.Size = new System.Drawing.Size(100, 23);
            this.makeOutput.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 302);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.brakeButton);
            this.Controls.Add(this.accelerateButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label speedOutput;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button brakeButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label makeOutput;
        private System.Windows.Forms.Label yearOutput;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label makeLabel;
    }
}

