﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 5/13/2018
* CSC 153
* Alex Lopez
* create a program that increases
* and decreases the speed of a vehicle
*/
namespace Car_Class
{
    public partial class Form1 : Form
    {
        // instantiate a Vehicle object with arguments
        Vehicle myCar = new Vehicle(2018, "Ford F-150");
        
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //display the vehicles year and make to the label
            yearOutput.Text = myCar.Year.ToString();
            makeOutput.Text = myCar.Make;
        }
        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // call the Accelerate() method to increase the vehicles speed
            myCar.Accelerate();
            // display the vehicles speed to the label
            speedOutput.Text = myCar.Speed.ToString();
        }
        private void brakeButton_Click(object sender, EventArgs e)
        {
            // call the Brake() method to decrease the vehicles speed
            myCar.Brake();
            // display the vehicles speed to the label
            speedOutput.Text = myCar.Speed.ToString();
        }
    }
}
