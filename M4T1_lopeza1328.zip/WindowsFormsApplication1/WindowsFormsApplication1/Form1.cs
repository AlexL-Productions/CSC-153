﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 3/21/2018
* CSC 153
* Alex Lopez
* miles to kilometers
*/

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            const int Start_Speed = 60;
            const int End_Speed = 130;
            const int Interval = 10;
            const double kilo_Factor = .6214;

            int kph;
            double mph;

            for (kph = Start_Speed; kph <= End_Speed; kph += Interval)
            {
                mph = kph * kilo_Factor;

                outputListBox.Items.Add(kph + " KPH is the same as " + mph + " MPH");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
