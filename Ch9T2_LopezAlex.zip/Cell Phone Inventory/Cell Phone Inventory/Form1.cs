﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
/**
* 5/7/2018
* CSC 153
* Alex Lopez
* This program prompts the user for their
* cellphone information and displays 
* it in a list. 
*/
namespace Cell_Phone_Inventory
{
    public partial class Form1 : Form
    {
        // create a List to hold CellPhone objects
        List<CellPhone> phoneList = new List<CellPhone>();

        public Form1()
        {
            InitializeComponent();
        }
        // the GetPhoneData method accpets  a cellPhone object as an argument
        // it assigns data entered by the user to its constructor parameter
        private void GetPhoneData(CellPhone phone)
        {
            // variable to hold the price data
            decimal price;

            // get the brand
            phone.Brand = brandTextBox.Text;

            // get the model
            phone.Model = modelTextBox.Text;

            // get the price
            if(decimal.TryParse(priceTextBox.Text, out price))
            {
                phone.Price = price;
            }
            else
            {
                // display an error message
                MessageBox.Show("invalid pirce");
            }
        }
        private void addPhoneButton_Click(object sender, EventArgs e)
        {
            // create new CellPhone object
            CellPhone myPhone = new CellPhone();

            /// get the phone data
            GetPhoneData(myPhone);

            // add the CellPhone object to the list
            phoneList.Add(myPhone);

            // add an entry to the list box
            phoneListBox.Items.Add(myPhone.Brand + " " + myPhone.Model);

            // clear the textBox 
            brandTextBox.Clear();
            modelTextBox.Clear();
            priceTextBox.Clear();

            // reset the focus
            brandTextBox.Focus();
        }

        private void phoneListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // get the index of the selected itme
            int index = phoneListBox.SelectedIndex;

            // display the selected item's price
            MessageBox.Show(phoneList[index].Price.ToString("c"));
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
