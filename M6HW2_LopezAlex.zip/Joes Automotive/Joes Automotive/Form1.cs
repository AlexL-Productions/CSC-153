﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * 4/20/2018
 * CSC 153
 * Alex Lopez
 * 
 * This program prompts the user to check
 * boxes for services done to their vehicles
 * and displays their invoice total
 * 
 */
namespace Joes_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // the OilLubeCharge method accepts two double parameters
        // and returns a total based on the boxe(s) the user checks
        private double OilLubeCharges(ref double oil, ref double lube)
        {
            if (oilCheckBox.Checked)
            {
                oil = 26;
            }
            if (lubeCheckBox.Checked)
            {
                lube = 18;
            }
            double total = oil + lube;
            return total;
        }
        // the FlushCharges method accepts two double parameters
        // and returns a total based on the boxe(s) the user checks
        private double FlushCharges(ref double flush, ref double trans)
        {
            if (radiatorCheckBox.Checked)
            {
                flush = 30;
            }
            if (transmissionCheckBox.Checked)
            {
                trans = 80;
            }
            double total = flush + trans;
            return total;
        }
        // the MiscCharges method accepts three double parameters
        // and returns a total based on the boxe(s) the user checks
        private double MiscCharges(ref double inspection, ref double muffler, ref double tire)
        {
            if (inspectionCheckBox.Checked)
            {
                inspection = 15;
            }
            if (mufflerCheckBox.Checked)
            {
                muffler = 100;
            }
            if (tireCheckBox.Checked)
            {
                tire = 20;
            }
            double total = inspection + muffler + tire;
            return total; 
        }
        // the OtherCharges method accepts two double parameters,
        // tests for correct data type input, and returns the total
        // base on the boxes the user checks
        private double OtherCharges(ref double parts, ref double labor)
        {
            if(double.TryParse(partsTextBox.Text, out parts))
            {
                if(double.TryParse(laborTextBox.Text, out labor))
                {
                    // labor is $20 per hour
                    labor *= 20;
                }
                else
                {
                    MessageBox.Show("input must be a number");
                }
            }
            else
            {
                MessageBox.Show("input must be a number");
            }
            double total = parts + labor;
            return total;
        }
        // the TaxCharges method accepts two double parameters
        // and returns the percentage tax 
        private double TaxCharges(ref double parts, ref double tax)
        {
            tax = parts * .06;
            return tax;
        }
        // the ClearOilLube method unchecks oil and lube check boxes
        private void ClearOilLube()
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }
        // the ClearFlushes method unchecks radiator and transmission check boxes
        private void ClearFlushes()
        {
            radiatorCheckBox.Checked = false;
            transmissionCheckBox.Checked = false;
        }
        // the ClearMisc method unchecks the rest of the check boxes
        private void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            mufflerCheckBox.Checked = false;
            tireCheckBox.Checked = false;
        }
        // the ClearOther method clears text from text boxes
        private void ClearOther()
        {
            partsTextBox.Clear();
            laborTextBox.Clear();
        }
        // the ClearFees method clears text from all labels
        private void ClearFees()
        {
            serviceOutput.Text = "";
            partsOutput.Text = "";
            taxOutput.Text = "";
            totalOutput.Text = "";
        }
      
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // all jobs, parts, and fees are given a variable
            // value is set to zero for referencing
            double oilJob = 0, lubeJob = 0;
            double flushJob = 0, transJob = 0;
            double inspectionJob = 0, mufflerJob = 0, tireJob =0;
            double partsCost = 0, tax = 0, labor = 0;

            // variables for the total cost of services and the total charges
            double serviceTotal, totalCharges;

            // the methods are called and provided with reference arguments
            // the reference arguments are permanently changed 
            OilLubeCharges(ref oilJob, ref lubeJob);
            FlushCharges(ref flushJob, ref transJob);
            MiscCharges(ref inspectionJob, ref mufflerJob, ref tireJob);
            OtherCharges(ref partsCost, ref labor);
            tax = TaxCharges(ref partsCost, ref tax);

            // total of all services excluding labor and parts
            serviceTotal = oilJob + lubeJob + flushJob + transJob + inspectionJob + mufflerJob + tireJob + labor;
            
            // the grand total (including parts and labor)
            totalCharges = serviceTotal + partsCost + tax;

            // display the charge(s)
            serviceOutput.Text = serviceTotal.ToString("c");
            partsOutput.Text = partsCost.ToString("C");
            taxOutput.Text = tax.ToString("c");
            totalOutput.Text = totalCharges.ToString("c"); 
        }
        
        private void clearButton_Click(object sender, EventArgs e)
        {
            // call the methods to clear/reset everything
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
