﻿namespace Joes_Automotive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilGroupBox = new System.Windows.Forms.GroupBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.transmissionCheckBox = new System.Windows.Forms.CheckBox();
            this.radiatorCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.tireCheckBox = new System.Windows.Forms.CheckBox();
            this.mufflerCheckBox = new System.Windows.Forms.CheckBox();
            this.inspectionCheckBox = new System.Windows.Forms.CheckBox();
            this.partsGroupBox = new System.Windows.Forms.GroupBox();
            this.laborTextBox = new System.Windows.Forms.TextBox();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.laborPromptLabel = new System.Windows.Forms.Label();
            this.partsPromptLabel = new System.Windows.Forms.Label();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.totalOutput = new System.Windows.Forms.Label();
            this.taxOutput = new System.Windows.Forms.Label();
            this.partsOutput = new System.Windows.Forms.Label();
            this.serviceOutput = new System.Windows.Forms.Label();
            this.totalFeesLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.partsLabel = new System.Windows.Forms.Label();
            this.serviceLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.oilGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.partsGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilGroupBox
            // 
            this.oilGroupBox.Controls.Add(this.lubeCheckBox);
            this.oilGroupBox.Controls.Add(this.oilCheckBox);
            this.oilGroupBox.Location = new System.Drawing.Point(38, 13);
            this.oilGroupBox.Name = "oilGroupBox";
            this.oilGroupBox.Size = new System.Drawing.Size(200, 77);
            this.oilGroupBox.TabIndex = 0;
            this.oilGroupBox.TabStop = false;
            this.oilGroupBox.Text = "Oil and Lube";
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Location = new System.Drawing.Point(6, 42);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(109, 17);
            this.lubeCheckBox.TabIndex = 1;
            this.lubeCheckBox.Text = "Lube job ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Location = new System.Drawing.Point(6, 19);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(120, 17);
            this.oilCheckBox.TabIndex = 0;
            this.oilCheckBox.Text = "Oil Change ($26.00)";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.transmissionCheckBox);
            this.flushesGroupBox.Controls.Add(this.radiatorCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(262, 13);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(200, 77);
            this.flushesGroupBox.TabIndex = 1;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // transmissionCheckBox
            // 
            this.transmissionCheckBox.AutoSize = true;
            this.transmissionCheckBox.Location = new System.Drawing.Point(6, 42);
            this.transmissionCheckBox.Name = "transmissionCheckBox";
            this.transmissionCheckBox.Size = new System.Drawing.Size(157, 17);
            this.transmissionCheckBox.TabIndex = 1;
            this.transmissionCheckBox.Text = "Transmission Flush ($80.00)";
            this.transmissionCheckBox.UseVisualStyleBackColor = true;
            // 
            // radiatorCheckBox
            // 
            this.radiatorCheckBox.AutoSize = true;
            this.radiatorCheckBox.Location = new System.Drawing.Point(6, 19);
            this.radiatorCheckBox.Name = "radiatorCheckBox";
            this.radiatorCheckBox.Size = new System.Drawing.Size(136, 17);
            this.radiatorCheckBox.TabIndex = 0;
            this.radiatorCheckBox.Text = "Radiator Flush ($30.00)";
            this.radiatorCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.tireCheckBox);
            this.miscGroupBox.Controls.Add(this.mufflerCheckBox);
            this.miscGroupBox.Controls.Add(this.inspectionCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(38, 96);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(200, 100);
            this.miscGroupBox.TabIndex = 2;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc";
            // 
            // tireCheckBox
            // 
            this.tireCheckBox.AutoSize = true;
            this.tireCheckBox.Location = new System.Drawing.Point(6, 65);
            this.tireCheckBox.Name = "tireCheckBox";
            this.tireCheckBox.Size = new System.Drawing.Size(129, 17);
            this.tireCheckBox.TabIndex = 2;
            this.tireCheckBox.Text = "Tire Rotation ($20.00)";
            this.tireCheckBox.UseVisualStyleBackColor = true;
            // 
            // mufflerCheckBox
            // 
            this.mufflerCheckBox.AutoSize = true;
            this.mufflerCheckBox.Location = new System.Drawing.Point(6, 42);
            this.mufflerCheckBox.Name = "mufflerCheckBox";
            this.mufflerCheckBox.Size = new System.Drawing.Size(149, 17);
            this.mufflerCheckBox.TabIndex = 1;
            this.mufflerCheckBox.Text = "Replace Muffler ($100.00)";
            this.mufflerCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspectionCheckBox
            // 
            this.inspectionCheckBox.AutoSize = true;
            this.inspectionCheckBox.Location = new System.Drawing.Point(6, 19);
            this.inspectionCheckBox.Name = "inspectionCheckBox";
            this.inspectionCheckBox.Size = new System.Drawing.Size(117, 17);
            this.inspectionCheckBox.TabIndex = 0;
            this.inspectionCheckBox.Text = "Inspection ($15.00)";
            this.inspectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsGroupBox
            // 
            this.partsGroupBox.Controls.Add(this.laborTextBox);
            this.partsGroupBox.Controls.Add(this.partsTextBox);
            this.partsGroupBox.Controls.Add(this.laborPromptLabel);
            this.partsGroupBox.Controls.Add(this.partsPromptLabel);
            this.partsGroupBox.Location = new System.Drawing.Point(262, 96);
            this.partsGroupBox.Name = "partsGroupBox";
            this.partsGroupBox.Size = new System.Drawing.Size(200, 100);
            this.partsGroupBox.TabIndex = 3;
            this.partsGroupBox.TabStop = false;
            this.partsGroupBox.Text = "Parts and Labor";
            // 
            // laborTextBox
            // 
            this.laborTextBox.Location = new System.Drawing.Point(94, 63);
            this.laborTextBox.Name = "laborTextBox";
            this.laborTextBox.Size = new System.Drawing.Size(69, 20);
            this.laborTextBox.TabIndex = 3;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(94, 29);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(69, 20);
            this.partsTextBox.TabIndex = 2;
            // 
            // laborPromptLabel
            // 
            this.laborPromptLabel.AutoSize = true;
            this.laborPromptLabel.Location = new System.Drawing.Point(17, 69);
            this.laborPromptLabel.Name = "laborPromptLabel";
            this.laborPromptLabel.Size = new System.Drawing.Size(71, 13);
            this.laborPromptLabel.TabIndex = 1;
            this.laborPromptLabel.Text = "Labor (Hours)";
            // 
            // partsPromptLabel
            // 
            this.partsPromptLabel.AutoSize = true;
            this.partsPromptLabel.Location = new System.Drawing.Point(57, 32);
            this.partsPromptLabel.Name = "partsPromptLabel";
            this.partsPromptLabel.Size = new System.Drawing.Size(31, 13);
            this.partsPromptLabel.TabIndex = 0;
            this.partsPromptLabel.Text = "Parts";
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.totalOutput);
            this.summaryGroupBox.Controls.Add(this.taxOutput);
            this.summaryGroupBox.Controls.Add(this.partsOutput);
            this.summaryGroupBox.Controls.Add(this.serviceOutput);
            this.summaryGroupBox.Controls.Add(this.totalFeesLabel);
            this.summaryGroupBox.Controls.Add(this.taxLabel);
            this.summaryGroupBox.Controls.Add(this.partsLabel);
            this.summaryGroupBox.Controls.Add(this.serviceLabel);
            this.summaryGroupBox.Location = new System.Drawing.Point(38, 202);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(424, 174);
            this.summaryGroupBox.TabIndex = 4;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // totalOutput
            // 
            this.totalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalOutput.Location = new System.Drawing.Point(143, 122);
            this.totalOutput.Name = "totalOutput";
            this.totalOutput.Size = new System.Drawing.Size(100, 23);
            this.totalOutput.TabIndex = 7;
            // 
            // taxOutput
            // 
            this.taxOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOutput.Location = new System.Drawing.Point(143, 86);
            this.taxOutput.Name = "taxOutput";
            this.taxOutput.Size = new System.Drawing.Size(100, 23);
            this.taxOutput.TabIndex = 6;
            // 
            // partsOutput
            // 
            this.partsOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.partsOutput.Location = new System.Drawing.Point(143, 50);
            this.partsOutput.Name = "partsOutput";
            this.partsOutput.Size = new System.Drawing.Size(100, 23);
            this.partsOutput.TabIndex = 5;
            // 
            // serviceOutput
            // 
            this.serviceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.serviceOutput.Location = new System.Drawing.Point(143, 16);
            this.serviceOutput.Name = "serviceOutput";
            this.serviceOutput.Size = new System.Drawing.Size(100, 23);
            this.serviceOutput.TabIndex = 4;
            // 
            // totalFeesLabel
            // 
            this.totalFeesLabel.AutoSize = true;
            this.totalFeesLabel.Location = new System.Drawing.Point(49, 123);
            this.totalFeesLabel.Name = "totalFeesLabel";
            this.totalFeesLabel.Size = new System.Drawing.Size(57, 13);
            this.totalFeesLabel.TabIndex = 3;
            this.totalFeesLabel.Text = "Total Fees";
            this.totalFeesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxLabel
            // 
            this.taxLabel.Location = new System.Drawing.Point(15, 82);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 23);
            this.taxLabel.TabIndex = 2;
            this.taxLabel.Text = "Tax (on parts)";
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // partsLabel
            // 
            this.partsLabel.Location = new System.Drawing.Point(72, 51);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(34, 23);
            this.partsLabel.TabIndex = 1;
            this.partsLabel.Text = "parts";
            // 
            // serviceLabel
            // 
            this.serviceLabel.Location = new System.Drawing.Point(6, 16);
            this.serviceLabel.Name = "serviceLabel";
            this.serviceLabel.Size = new System.Drawing.Size(100, 23);
            this.serviceLabel.TabIndex = 0;
            this.serviceLabel.Text = "Service and Labor";
            this.serviceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(113, 382);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 34);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(206, 382);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 34);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(314, 382);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 34);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 446);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.partsGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.oilGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.oilGroupBox.ResumeLayout(false);
            this.oilGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.partsGroupBox.ResumeLayout(false);
            this.partsGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.summaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oilGroupBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox transmissionCheckBox;
        private System.Windows.Forms.CheckBox radiatorCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.CheckBox tireCheckBox;
        private System.Windows.Forms.CheckBox mufflerCheckBox;
        private System.Windows.Forms.CheckBox inspectionCheckBox;
        private System.Windows.Forms.GroupBox partsGroupBox;
        private System.Windows.Forms.TextBox laborTextBox;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.Label laborPromptLabel;
        private System.Windows.Forms.Label partsPromptLabel;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Label totalOutput;
        private System.Windows.Forms.Label taxOutput;
        private System.Windows.Forms.Label partsOutput;
        private System.Windows.Forms.Label serviceOutput;
        private System.Windows.Forms.Label totalFeesLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.Label serviceLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

