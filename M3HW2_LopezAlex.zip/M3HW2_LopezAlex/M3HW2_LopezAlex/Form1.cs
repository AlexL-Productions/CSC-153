﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_LopezAlex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            const int packagePrice = 99;
            int amount = 0;
            double discount =0;
            double total;

            if(int.TryParse(amountBox.Text, out amount))
            {
                if (amount > 0 && amount < 10)
                {
                    outputLabel.Text = "N/A";
                }
                if (amount > 9 && amount < 20)
                {
                    outputLabel.Text = "20%";
                    discount = .2;
                }
                if (amount > 19 && amount < 50)
                {
                    outputLabel.Text = "30%";
                    discount = .3;
                }
                if (amount > 49 && amount < 99)
                {
                   outputLabel.Text = "40%";
                   discount = .4;
                }
                if (amount > 99)
                {
                outputLabel.Text = "50%";
                discount = .5;
                }

                total = packagePrice * amount;
                discount = discount * total;
                total = total - discount;
                totalLabel.Text = total.ToString("c");

                }
                else
                {
                    MessageBox.Show("Invalid Input");
                }
            }

            private void exitButton_Click(object sender, EventArgs e)
            {
                this.Close();
            }
        }
    }
