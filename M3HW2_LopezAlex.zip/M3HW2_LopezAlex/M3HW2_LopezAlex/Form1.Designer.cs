﻿namespace M3HW2_LopezAlex
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packagePrompt = new System.Windows.Forms.Label();
            this.discountprompt = new System.Windows.Forms.Label();
            this.totalPrompt = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.amountBox = new System.Windows.Forms.TextBox();
            this.totalButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // packagePrompt
            // 
            this.packagePrompt.Location = new System.Drawing.Point(39, 28);
            this.packagePrompt.Name = "packagePrompt";
            this.packagePrompt.Size = new System.Drawing.Size(100, 23);
            this.packagePrompt.TabIndex = 0;
            this.packagePrompt.Text = "Package x1:  $99";
            // 
            // discountprompt
            // 
            this.discountprompt.Location = new System.Drawing.Point(39, 65);
            this.discountprompt.Name = "discountprompt";
            this.discountprompt.Size = new System.Drawing.Size(100, 23);
            this.discountprompt.TabIndex = 1;
            this.discountprompt.Text = "Discount ";
            // 
            // totalPrompt
            // 
            this.totalPrompt.Location = new System.Drawing.Point(39, 105);
            this.totalPrompt.Name = "totalPrompt";
            this.totalPrompt.Size = new System.Drawing.Size(100, 23);
            this.totalPrompt.TabIndex = 2;
            this.totalPrompt.Text = "Net Total";
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(180, 64);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(100, 23);
            this.outputLabel.TabIndex = 3;
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalLabel.Location = new System.Drawing.Point(180, 104);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(100, 23);
            this.totalLabel.TabIndex = 4;
            // 
            // amountBox
            // 
            this.amountBox.Location = new System.Drawing.Point(180, 25);
            this.amountBox.Name = "amountBox";
            this.amountBox.Size = new System.Drawing.Size(100, 20);
            this.amountBox.TabIndex = 5;
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(107, 168);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(75, 23);
            this.totalButton.TabIndex = 6;
            this.totalButton.Text = "Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(188, 168);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.amountBox);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.totalPrompt);
            this.Controls.Add(this.discountprompt);
            this.Controls.Add(this.packagePrompt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label packagePrompt;
        private System.Windows.Forms.Label discountprompt;
        private System.Windows.Forms.Label totalPrompt;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.TextBox amountBox;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button exitButton;
    }
}

