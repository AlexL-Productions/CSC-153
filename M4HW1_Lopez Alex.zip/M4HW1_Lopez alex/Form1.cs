﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 3/29/2018
 * CSC 153
 * Alex Lopez
 * Population calculator
 * */

namespace M4HW1_Lopez_alex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void multiplyButton_Click(object sender, EventArgs e)
        {
            //create variables for input
            int days;
            double organisms;
            double percent;

            //check for correct input value
            if (double.TryParse(amountTextBox.Text, out organisms))
            {
                //check for correct input value
                if (double.TryParse(percentTextBox.Text, out percent))
                {
                    //convert percentage input to decimal
                    percent /= 100;

                    //check for correct input value
                    if (int.TryParse(daysTextBox.Text, out days))
                    {
                        //add text headers for days and total
                        listBox1.Items.Add("Days\t\tTotal");

                        //get population increase for amount of days
                        for (int x = 1; x <= days; x++)
                        {
                            //display output in listBox
                            listBox1.Items.Add(days + "\t\t" + organisms);

                            //accumulate number of organisms by daily percent increase
                            organisms += (percent * organisms);
                        }
                    //for all else statements display error Message
                    }
                    else
                    {
                        MessageBox.Show("Invalid input for days");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input for percent");
                }
            }
            else
            {
                MessageBox.Show("Invalid input for organisms");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clear all text
            amountTextBox.Text = "";
            percentTextBox.Text = "";
            daysTextBox.Text = "";

            //clear listBox text
            listBox1.Items.Clear();
            //shift focus to beginning
            amountTextBox.Focus();
        }

        private void esxitButton_Click(object sender, EventArgs e)
        {
            //close the program
            this.Close();
        }
    }
}
