﻿namespace M4HW1_Lopez_alex
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.amountLabel = new System.Windows.Forms.Label();
            this.percentLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.percentTextBox = new System.Windows.Forms.TextBox();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.multiplyButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.esxitButton = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // amountLabel
            // 
            this.amountLabel.Location = new System.Drawing.Point(26, 13);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(100, 23);
            this.amountLabel.TabIndex = 0;
            this.amountLabel.Text = "Starting Organims:";
            // 
            // percentLabel
            // 
            this.percentLabel.Location = new System.Drawing.Point(17, 36);
            this.percentLabel.Name = "percentLabel";
            this.percentLabel.Size = new System.Drawing.Size(109, 23);
            this.percentLabel.TabIndex = 1;
            this.percentLabel.Text = "Percentage Increase:";
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(42, 59);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(84, 13);
            this.daysLabel.TabIndex = 2;
            this.daysLabel.Text = "Days to Multiply:";
            // 
            // amountTextBox
            // 
            this.amountTextBox.Location = new System.Drawing.Point(172, 10);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(100, 20);
            this.amountTextBox.TabIndex = 3;
            // 
            // percentTextBox
            // 
            this.percentTextBox.Location = new System.Drawing.Point(172, 33);
            this.percentTextBox.Name = "percentTextBox";
            this.percentTextBox.Size = new System.Drawing.Size(100, 20);
            this.percentTextBox.TabIndex = 4;
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(172, 56);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysTextBox.TabIndex = 5;
            // 
            // multiplyButton
            // 
            this.multiplyButton.Location = new System.Drawing.Point(29, 266);
            this.multiplyButton.Name = "multiplyButton";
            this.multiplyButton.Size = new System.Drawing.Size(81, 39);
            this.multiplyButton.TabIndex = 7;
            this.multiplyButton.Text = "Multiply Organisms";
            this.multiplyButton.UseVisualStyleBackColor = true;
            this.multiplyButton.Click += new System.EventHandler(this.multiplyButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(116, 266);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 39);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // esxitButton
            // 
            this.esxitButton.Location = new System.Drawing.Point(197, 266);
            this.esxitButton.Name = "esxitButton";
            this.esxitButton.Size = new System.Drawing.Size(75, 40);
            this.esxitButton.TabIndex = 9;
            this.esxitButton.Text = "Exit";
            this.esxitButton.UseVisualStyleBackColor = true;
            this.esxitButton.Click += new System.EventHandler(this.esxitButton_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(20, 89);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(252, 160);
            this.listBox1.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 337);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.esxitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.multiplyButton);
            this.Controls.Add(this.daysTextBox);
            this.Controls.Add(this.percentTextBox);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(this.daysLabel);
            this.Controls.Add(this.percentLabel);
            this.Controls.Add(this.amountLabel);
            this.Name = "Form1";
            this.Text = "2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.Label percentLabel;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.TextBox percentTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.Button multiplyButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button esxitButton;
        private System.Windows.Forms.ListBox listBox1;
    }
}

